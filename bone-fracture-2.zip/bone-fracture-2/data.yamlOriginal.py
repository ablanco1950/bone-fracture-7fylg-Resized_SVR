train: ../train/images
val: ../valid/images
test: ../test/images

nc: 4
names: ['angle', 'fracture', 'line', 'messed_up_angle']

roboflow:
  workspace: roboflow-100
  project: bone-fracture-7fylg
  version: 2
  license: CC BY 4.0
  url: https://universe.roboflow.com/roboflow-100/bone-fracture-7fylg/dataset/2
